import { AddressTypePipe } from './address-type.pipe';

describe('AddressTypePipe', () => {
  it('create an instance', () => {
    const pipe = new AddressTypePipe();
    expect(pipe).toBeTruthy();
  });
});
