import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-food-search-with-address',
  templateUrl: './get-food-search-with-address.page.html',
  styleUrls: ['./get-food-search-with-address.page.scss'],
})
export class GetFoodSearchWithAddressPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
