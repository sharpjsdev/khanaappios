import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VolunteerFoodRequestPageRoutingModule } from './volunteer-food-request-routing.module';

import { VolunteerFoodRequestPage } from './volunteer-food-request.page';
import { CaptchaComponent } from '../captcha/captcha.component';
import { FooterPageModule } from "../footer/footer.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VolunteerFoodRequestPageRoutingModule,
    FooterPageModule
  ],
  declarations: [VolunteerFoodRequestPage,CaptchaComponent]
})
export class VolunteerFoodRequestPageModule {}
