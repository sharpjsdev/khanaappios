import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extact-pin',
  templateUrl: './extact-pin.page.html',
  styleUrls: ['./extact-pin.page.scss'],
})
export class ExtactPinPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
