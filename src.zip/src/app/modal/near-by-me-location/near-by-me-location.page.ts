import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-near-by-me-location',
  templateUrl: './near-by-me-location.page.html',
  styleUrls: ['./near-by-me-location.page.scss'],
})
export class NearByMeLocationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
