import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donate-food-successful',
  templateUrl: './donate-food-successful.page.html',
  styleUrls: ['./donate-food-successful.page.scss'],
})
export class DonateFoodSuccessfulPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
