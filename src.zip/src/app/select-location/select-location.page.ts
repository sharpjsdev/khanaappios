import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-location',
  templateUrl: './select-location.page.html',
  styleUrls: ['./select-location.page.scss'],
})
export class SelectLocationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
